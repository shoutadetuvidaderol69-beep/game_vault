import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  Pressable,
  Dimensions,
  FlatList,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CATALOG, TAGLINE, getImage } from '../data/catalog';
import ProductCard from '../components/ProductCard';
import { useCart } from '../context/CartContext';

const { width } = Dimensions.get('window');

export default function HomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { count } = useCart();

  const featured = useMemo(
    () => CATALOG.filter((p) => p.featured).slice(0, 8),
    []
  );

  const heroProduct = featured[0] || CATALOG[0];
  const heroImg = getImage(heroProduct?.hero) || getImage(heroProduct?.image);

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <View>
          <Text style={styles.logo}>GameVault</Text>
          <Text style={styles.tagline} numberOfLines={1}>
            {TAGLINE}
          </Text>
        </View>
        <Pressable
          style={styles.cartBtn}
          onPress={() => navigation.navigate('Cart')}
        >
          <Text style={styles.cartIcon}>🛒</Text>
          {count > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{count}</Text>
            </View>
          )}
        </Pressable>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 24 }}
      >
        {/* Hero */}
        <Pressable
          style={styles.hero}
          onPress={() =>
            heroProduct && navigation.navigate('Product', { id: heroProduct.id })
          }
        >
          {heroImg ? (
            <Image source={heroImg} style={styles.heroImg} resizeMode="cover" />
          ) : (
            <View style={[styles.heroImg, styles.heroPlaceholder]} />
          )}
          <View style={styles.heroOverlay}>
            <Text style={styles.heroKind}>DESTACADO</Text>
            <Text style={styles.heroTitle} numberOfLines={2}>
              {heroProduct?.title}
            </Text>
            <Text style={styles.heroPrice}>
              ${heroProduct?.price}
              {heroProduct?.compareAt ? (
                <Text style={styles.heroCompare}> ${heroProduct.compareAt}</Text>
              ) : null}
            </Text>
          </View>
        </Pressable>

        {/* Quick categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Categorías</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {[
              { id: 'juego', label: 'Juegos', emoji: '🎮' },
              { id: 'consola', label: 'Consolas', emoji: '🖥️' },
              { id: 'accesorio', label: 'Accesorios', emoji: '🎧' },
              { id: 'equipo', label: 'Equipo', emoji: '🪑' },
            ].map((cat) => (
              <Pressable
                key={cat.id}
                style={styles.catChip}
                onPress={() =>
                  navigation.navigate('Browse', { kind: cat.id })
                }
              >
                <Text style={styles.catEmoji}>{cat.emoji}</Text>
                <Text style={styles.catLabel}>{cat.label}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Featured grid */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Destacados</Text>
            <Pressable onPress={() => navigation.navigate('Browse')}>
              <Text style={styles.seeAll}>Ver todos →</Text>
            </Pressable>
          </View>
          <View style={styles.grid}>
            {featured.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onPress={(prod) =>
                  navigation.navigate('Product', { id: prod.id })
                }
              />
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0b0d12',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  logo: {
    color: '#f1f5f9',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  tagline: {
    color: '#64748b',
    fontSize: 11,
    maxWidth: width * 0.65,
  },
  cartBtn: {
    width: 42,
    height: 42,
    borderRadius: 12,
    backgroundColor: '#151922',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#1f2533',
  },
  cartIcon: {
    fontSize: 18,
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#e11d48',
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
  },
  hero: {
    marginHorizontal: 16,
    height: 200,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 20,
  },
  heroImg: {
    width: '100%',
    height: '100%',
  },
  heroPlaceholder: {
    backgroundColor: '#1a1f2e',
  },
  heroOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: 16,
    backgroundColor: 'rgba(0,0,0,0.55)',
  },
  heroKind: {
    color: '#38bdf8',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    marginBottom: 4,
  },
  heroTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  heroPrice: {
    color: '#38bdf8',
    fontSize: 16,
    fontWeight: '700',
  },
  heroCompare: {
    color: '#94a3b8',
    fontSize: 13,
    textDecorationLine: 'line-through',
    fontWeight: '400',
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#f1f5f9',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 12,
  },
  seeAll: {
    color: '#38bdf8',
    fontSize: 13,
    fontWeight: '600',
  },
  catChip: {
    backgroundColor: '#151922',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginRight: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#1f2533',
    minWidth: 90,
  },
  catEmoji: {
    fontSize: 22,
    marginBottom: 4,
  },
  catLabel: {
    color: '#e2e8f0',
    fontSize: 12,
    fontWeight: '600',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});
