import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  Pressable,
  ScrollView,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CATALOG, KINDS, PLATFORMS } from '../data/catalog';
import ProductCard from '../components/ProductCard';

export default function BrowseScreen({ navigation, route }) {
  const insets = useSafeAreaInsets();
  const initialKind = route?.params?.kind || 'all';

  const [query, setQuery] = useState('');
  const [kind, setKind] = useState(initialKind);
  const [platform, setPlatform] = useState('all');

  useEffect(() => {
    if (route?.params?.kind) setKind(route.params.kind);
  }, [route?.params?.kind]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CATALOG.filter((p) => {
      if (kind !== 'all' && p.kind !== kind) return false;
      if (
        platform !== 'all' &&
        !(p.platforms || []).some((pl) =>
          pl.toLowerCase().includes(platform.toLowerCase())
        )
      )
        return false;
      if (!q) return true;
      const hay = `${p.title} ${p.blurb || ''} ${(p.platforms || []).join(' ')}`.toLowerCase();
      return hay.includes(q);
    });
  }, [query, kind, platform]);

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Explorar</Text>
        <Text style={styles.count}>{filtered.length} productos</Text>
      </View>

      <View style={styles.searchWrap}>
        <TextInput
          style={styles.search}
          placeholder="Buscar juegos, consolas..."
          placeholderTextColor="#64748b"
          value={query}
          onChangeText={setQuery}
          clearButtonMode="while-editing"
        />
      </View>

      {/* Kind filters */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filters}
      >
        {KINDS.map((k) => (
          <Pressable
            key={k.id}
            style={[styles.chip, kind === k.id && styles.chipActive]}
            onPress={() => setKind(k.id)}
          >
            <Text
              style={[styles.chipText, kind === k.id && styles.chipTextActive]}
            >
              {k.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Platform filters */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={[styles.filters, { paddingTop: 0 }]}
      >
        {PLATFORMS.map((p) => (
          <Pressable
            key={p.id}
            style={[styles.chipSmall, platform === p.id && styles.chipActive]}
            onPress={() => setPlatform(p.id)}
          >
            <Text
              style={[
                styles.chipTextSmall,
                platform === p.id && styles.chipTextActive,
              ]}
            >
              {p.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <Text style={styles.empty}>No se encontraron productos.</Text>
        }
        renderItem={({ item }) => (
          <ProductCard
            product={item}
            onPress={(prod) => navigation.navigate('Product', { id: prod.id })}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0b0d12',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  title: {
    color: '#f1f5f9',
    fontSize: 22,
    fontWeight: '800',
  },
  count: {
    color: '#64748b',
    fontSize: 13,
  },
  searchWrap: {
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  search: {
    backgroundColor: '#151922',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: '#f1f5f9',
    fontSize: 15,
    borderWidth: 1,
    borderColor: '#1f2533',
  },
  filters: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    gap: 8,
  },
  chip: {
    backgroundColor: '#151922',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#1f2533',
  },
  chipSmall: {
    backgroundColor: '#151922',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#1f2533',
  },
  chipActive: {
    backgroundColor: '#0ea5e9',
    borderColor: '#0ea5e9',
  },
  chipText: {
    color: '#94a3b8',
    fontSize: 13,
    fontWeight: '600',
  },
  chipTextSmall: {
    color: '#94a3b8',
    fontSize: 12,
    fontWeight: '600',
  },
  chipTextActive: {
    color: '#fff',
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  row: {
    justifyContent: 'space-between',
  },
  empty: {
    color: '#64748b',
    textAlign: 'center',
    marginTop: 40,
    fontSize: 15,
  },
});
