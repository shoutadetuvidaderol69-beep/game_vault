import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  Pressable,
  ScrollView,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CATALOG, getImage } from '../data/catalog';
import { useCart } from '../context/CartContext';

const PAYMENT_METHODS = [
  'Tarjeta de crédito o débito',
  'PayPal',
  'Mercado Pago',
  'Transferencia SPEI',
  'Efectivo en OXXO',
];

export default function CartScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { items, setQty, remove, clear, count } = useCart();
  const [payment, setPayment] = useState(PAYMENT_METHODS[0]);
  const [checkingOut, setCheckingOut] = useState(false);

  const lines = useMemo(() => {
    return items
      .map((item) => {
        const product = CATALOG.find((p) => p.id === item.id);
        if (!product) return null;
        return { ...item, product };
      })
      .filter(Boolean);
  }, [items]);

  const total = useMemo(
    () => lines.reduce((sum, l) => sum + l.product.price * l.qty, 0),
    [lines]
  );

  const handleCheckout = () => {
    if (lines.length === 0) return;
    setCheckingOut(true);
    const folio = 'GV-' + Date.now().toString(36).toUpperCase().slice(-8);
    setTimeout(() => {
      clear();
      setCheckingOut(false);
      Alert.alert(
        '¡Pedido confirmado!',
        `Esta es una simulación. No se realizó ningún cargo real.\n\nFolio: ${folio}\nMétodo: ${payment}\nTotal: $${total}`,
        [{ text: 'OK' }]
      );
    }, 800);
  };

  if (lines.length === 0) {
    return (
      <View style={[styles.root, styles.center, { paddingTop: insets.top }]}>
        <Text style={styles.emptyIcon}>🛒</Text>
        <Text style={styles.emptyTitle}>Tu carrito está vacío</Text>
        <Text style={styles.emptySub}>
          Explora el catálogo y agrega tus juegos favoritos.
        </Text>
        <Pressable
          style={styles.exploreBtn}
          onPress={() => navigation.navigate('Browse')}
        >
          <Text style={styles.exploreBtnText}>Explorar catálogo</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Carrito</Text>
        <Text style={styles.count}>{count} artículo{count !== 1 ? 's' : ''}</Text>
      </View>

      <FlatList
        data={lines}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 20 }}
        renderItem={({ item }) => {
          const img = getImage(item.product.image);
          return (
            <View style={styles.line}>
              {img ? (
                <Image source={img} style={styles.thumb} resizeMode="cover" />
              ) : (
                <View style={[styles.thumb, styles.thumbPlaceholder]} />
              )}
              <View style={styles.lineBody}>
                <Text style={styles.lineTitle} numberOfLines={2}>
                  {item.product.title}
                </Text>
                <Text style={styles.linePrice}>${item.product.price}</Text>
                <View style={styles.qtyRow}>
                  <Pressable
                    style={styles.qtyBtn}
                    onPress={() => setQty(item.id, item.qty - 1)}
                  >
                    <Text style={styles.qtyBtnText}>−</Text>
                  </Pressable>
                  <Text style={styles.qty}>{item.qty}</Text>
                  <Pressable
                    style={styles.qtyBtn}
                    onPress={() => setQty(item.id, item.qty + 1)}
                  >
                    <Text style={styles.qtyBtnText}>+</Text>
                  </Pressable>
                  <Pressable
                    style={styles.removeBtn}
                    onPress={() => remove(item.id)}
                  >
                    <Text style={styles.removeText}>Eliminar</Text>
                  </Pressable>
                </View>
              </View>
            </View>
          );
        }}
        ListFooterComponent={
          <View style={styles.footer}>
            <Text style={styles.paymentLabel}>Método de pago (demo)</Text>
            {PAYMENT_METHODS.map((m) => (
              <Pressable
                key={m}
                style={[styles.payOption, payment === m && styles.payOptionActive]}
                onPress={() => setPayment(m)}
              >
                <Text
                  style={[
                    styles.payOptionText,
                    payment === m && styles.payOptionTextActive,
                  ]}
                >
                  {m}
                </Text>
              </Pressable>
            ))}

            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>${total}</Text>
            </View>

            <Pressable
              style={[styles.checkoutBtn, checkingOut && styles.checkoutDisabled]}
              onPress={handleCheckout}
              disabled={checkingOut}
            >
              <Text style={styles.checkoutText}>
                {checkingOut ? 'Procesando…' : 'Confirmar pedido (demo)'}
              </Text>
            </Pressable>
            <Text style={styles.disclaimer}>
              Simulación. No se conecta con bancos ni genera cargos reales.
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0b0d12',
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyTitle: {
    color: '#f1f5f9',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 8,
  },
  emptySub: {
    color: '#64748b',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  exploreBtn: {
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
  },
  exploreBtnText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 15,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    color: '#f1f5f9',
    fontSize: 22,
    fontWeight: '800',
  },
  count: {
    color: '#64748b',
    fontSize: 13,
  },
  line: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1f2e',
  },
  thumb: {
    width: 72,
    height: 90,
    borderRadius: 10,
    backgroundColor: '#151922',
  },
  thumbPlaceholder: {
    backgroundColor: '#1a1f2e',
  },
  lineBody: {
    flex: 1,
    marginLeft: 12,
  },
  lineTitle: {
    color: '#f1f5f9',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  linePrice: {
    color: '#38bdf8',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 8,
  },
  qtyRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  qtyBtn: {
    width: 30,
    height: 30,
    borderRadius: 8,
    backgroundColor: '#1e293b',
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyBtnText: {
    color: '#f1f5f9',
    fontSize: 16,
    fontWeight: '600',
  },
  qty: {
    color: '#f1f5f9',
    fontSize: 15,
    fontWeight: '600',
    marginHorizontal: 12,
    minWidth: 20,
    textAlign: 'center',
  },
  removeBtn: {
    marginLeft: 16,
  },
  removeText: {
    color: '#ef4444',
    fontSize: 13,
  },
  footer: {
    padding: 16,
    paddingTop: 20,
  },
  paymentLabel: {
    color: '#94a3b8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 10,
  },
  payOption: {
    backgroundColor: '#151922',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 10,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#1f2533',
  },
  payOptionActive: {
    borderColor: '#0ea5e9',
    backgroundColor: '#0c1929',
  },
  payOptionText: {
    color: '#94a3b8',
    fontSize: 14,
  },
  payOptionTextActive: {
    color: '#38bdf8',
    fontWeight: '600',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 16,
  },
  totalLabel: {
    color: '#94a3b8',
    fontSize: 16,
  },
  totalValue: {
    color: '#f1f5f9',
    fontSize: 24,
    fontWeight: '800',
  },
  checkoutBtn: {
    backgroundColor: '#0ea5e9',
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  checkoutDisabled: {
    opacity: 0.6,
  },
  checkoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  disclaimer: {
    color: '#475569',
    fontSize: 11,
    textAlign: 'center',
    marginTop: 12,
  },
});
