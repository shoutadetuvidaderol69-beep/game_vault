import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ABOUT, TAGLINE, getImage } from '../data/catalog';

export default function AboutScreen() {
  const insets = useSafeAreaInsets();
  const logo = getImage('heroes/logo-gamevault.png');

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <ScrollView contentContainerStyle={styles.content}>
        {logo ? (
          <Image source={logo} style={styles.logo} resizeMode="contain" />
        ) : null}
        <Text style={styles.title}>GameVault</Text>
        <Text style={styles.tagline}>{TAGLINE}</Text>

        {ABOUT.map((para, i) => (
          <Text key={i} style={styles.para}>
            {para}
          </Text>
        ))}

        <View style={styles.box}>
          <Text style={styles.boxTitle}>Sobre esta app</Text>
          <Text style={styles.boxText}>
            Esta es la versión móvil (Expo) del catálogo GameVault. El carrito y
            los métodos de pago son solo una demostración local. No se procesan
            pagos reales ni se envían datos a ningún servidor.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0b0d12',
  },
  content: {
    padding: 24,
    paddingBottom: 40,
  },
  logo: {
    width: 120,
    height: 120,
    alignSelf: 'center',
    marginBottom: 16,
  },
  title: {
    color: '#f1f5f9',
    fontSize: 28,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 8,
  },
  tagline: {
    color: '#38bdf8',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 28,
    lineHeight: 20,
  },
  para: {
    color: '#94a3b8',
    fontSize: 15,
    lineHeight: 24,
    marginBottom: 16,
  },
  box: {
    backgroundColor: '#151922',
    borderRadius: 14,
    padding: 16,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#1f2533',
  },
  boxTitle: {
    color: '#f1f5f9',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 8,
  },
  boxText: {
    color: '#64748b',
    fontSize: 13,
    lineHeight: 20,
  },
});
