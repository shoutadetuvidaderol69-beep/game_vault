import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  Pressable,
  Dimensions,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CATALOG, getImage } from '../data/catalog';
import { useCart } from '../context/CartContext';

const { width } = Dimensions.get('window');

export default function ProductScreen({ navigation, route }) {
  const insets = useSafeAreaInsets();
  const { id } = route.params || {};
  const { add } = useCart();
  const [added, setAdded] = useState(false);

  const product = useMemo(
    () => CATALOG.find((p) => p.id === id),
    [id]
  );

  if (!product) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text style={styles.missing}>Producto no encontrado</Text>
        <Pressable onPress={() => navigation.goBack()}>
          <Text style={styles.backLink}>← Volver</Text>
        </Pressable>
      </View>
    );
  }

  const img = getImage(product.hero) || getImage(product.image);
  const hasDiscount =
    product.compareAt && product.compareAt > product.price;

  const handleAdd = () => {
    add(product.id, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <View style={styles.topBar}>
        <Pressable onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>← Atrás</Text>
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.imageWrap}>
          {img ? (
            <Image source={img} style={styles.image} resizeMode="cover" />
          ) : (
            <View style={[styles.image, styles.placeholder]} />
          )}
        </View>

        <View style={styles.body}>
          <Text style={styles.kind}>{product.kind?.toUpperCase()}</Text>
          <Text style={styles.title}>{product.title}</Text>

          <View style={styles.meta}>
            {(product.platforms || []).map((pl) => (
              <View key={pl} style={styles.platformChip}>
                <Text style={styles.platformText}>{pl}</Text>
              </View>
            ))}
            {product.format && (
              <View style={styles.platformChip}>
                <Text style={styles.platformText}>{product.format}</Text>
              </View>
            )}
          </View>

          {product.rating != null && (
            <Text style={styles.rating}>
              ★ {product.rating} · {product.reviews || 0} reseñas
            </Text>
          )}

          <View style={styles.priceBlock}>
            <Text style={styles.price}>${product.price}</Text>
            {hasDiscount && (
              <>
                <Text style={styles.compare}>${product.compareAt}</Text>
                <View style={styles.discountBadge}>
                  <Text style={styles.discountText}>
                    -
                    {Math.round(
                      ((product.compareAt - product.price) /
                        product.compareAt) *
                        100
                    )}
                    %
                  </Text>
                </View>
              </>
            )}
          </View>

          {product.blurb ? (
            <Text style={styles.blurb}>{product.blurb}</Text>
          ) : null}

          <Pressable
            style={[styles.addBtn, added && styles.addBtnDone]}
            onPress={handleAdd}
          >
            <Text style={styles.addBtnText}>
              {added ? '✓ Agregado al carrito' : 'Agregar al carrito'}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0b0d12',
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  missing: {
    color: '#94a3b8',
    fontSize: 16,
    marginBottom: 12,
  },
  backLink: {
    color: '#38bdf8',
    fontSize: 15,
  },
  topBar: {
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  backBtn: {
    paddingVertical: 6,
    paddingHorizontal: 8,
  },
  backText: {
    color: '#38bdf8',
    fontSize: 15,
    fontWeight: '600',
  },
  imageWrap: {
    width: width,
    height: width * 0.9,
    backgroundColor: '#0d1017',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  placeholder: {
    backgroundColor: '#1a1f2e',
  },
  body: {
    padding: 20,
    paddingBottom: 40,
  },
  kind: {
    color: '#7c8aa5',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  title: {
    color: '#f1f5f9',
    fontSize: 24,
    fontWeight: '800',
    lineHeight: 30,
    marginBottom: 12,
  },
  meta: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 10,
  },
  platformChip: {
    backgroundColor: '#1e293b',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  platformText: {
    color: '#cbd5e1',
    fontSize: 12,
    fontWeight: '600',
  },
  rating: {
    color: '#fbbf24',
    fontSize: 14,
    marginBottom: 14,
  },
  priceBlock: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  price: {
    color: '#38bdf8',
    fontSize: 28,
    fontWeight: '800',
  },
  compare: {
    color: '#64748b',
    fontSize: 16,
    textDecorationLine: 'line-through',
  },
  discountBadge: {
    backgroundColor: '#e11d48',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  discountText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  blurb: {
    color: '#94a3b8',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 24,
  },
  addBtn: {
    backgroundColor: '#0ea5e9',
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  addBtnDone: {
    backgroundColor: '#059669',
  },
  addBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
