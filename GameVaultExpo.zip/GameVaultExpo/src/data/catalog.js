// Auto-generated catalog for GameVault Expo
const images = {
  "covers/acmirage.jpg": require("../../assets/covers/acmirage.jpg"),
  "covers/acshadows.jpg": require("../../assets/covers/acshadows.jpg"),
  "covers/batman.jpg": require("../../assets/covers/batman.jpg"),
  "covers/bond.jpg": require("../../assets/covers/bond.jpg"),
  "covers/bully.jpg": require("../../assets/covers/bully.jpg"),
  "covers/chair-gray.jpg": require("../../assets/covers/chair-gray.jpg"),
  "covers/chair-red-black.jpg": require("../../assets/covers/chair-red-black.jpg"),
  "covers/cod3.jpg": require("../../assets/covers/cod3.jpg"),
  "covers/console-ps4-pro-god-of-war.jpg": require("../../assets/covers/console-ps4-pro-god-of-war.jpg"),
  "covers/console-ps4.jpg": require("../../assets/covers/console-ps4.jpg"),
  "covers/console-ps5-spiderman.jpg": require("../../assets/covers/console-ps5-spiderman.jpg"),
  "covers/console-ps5.jpg": require("../../assets/covers/console-ps5.jpg"),
  "covers/console-switch-splatoon.jpg": require("../../assets/covers/console-switch-splatoon.jpg"),
  "covers/console-switch.jpg": require("../../assets/covers/console-switch.jpg"),
  "covers/console-xbox-bmo.jpg": require("../../assets/covers/console-xbox-bmo.jpg"),
  "covers/console-xbox-series-x.jpg": require("../../assets/covers/console-xbox-series-x.jpg"),
  "covers/control-dualsense-spiderman.jpg": require("../../assets/covers/control-dualsense-spiderman.jpg"),
  "covers/control-dualsense.jpg": require("../../assets/covers/control-dualsense.jpg"),
  "covers/control-ps4-pack.jpg": require("../../assets/covers/control-ps4-pack.jpg"),
  "covers/control-xbox.jpg": require("../../assets/covers/control-xbox.jpg"),
  "covers/cyber.jpg": require("../../assets/covers/cyber.jpg"),
  "covers/dbx2.jpg": require("../../assets/covers/dbx2.jpg"),
  "covers/dmc5.jpg": require("../../assets/covers/dmc5.jpg"),
  "covers/dsr.jpg": require("../../assets/covers/dsr.jpg"),
  "covers/elden.jpg": require("../../assets/covers/elden.jpg"),
  "covers/forza5.jpg": require("../../assets/covers/forza5.jpg"),
  "covers/gang.jpg": require("../../assets/covers/gang.jpg"),
  "covers/gears5.jpg": require("../../assets/covers/gears5.jpg"),
  "covers/gow.jpg": require("../../assets/covers/gow.jpg"),
  "covers/gowr.jpg": require("../../assets/covers/gowr.jpg"),
  "covers/gta5.jpg": require("../../assets/covers/gta5.jpg"),
  "covers/gtasa.jpg": require("../../assets/covers/gtasa.jpg"),
  "covers/halo.jpg": require("../../assets/covers/halo.jpg"),
  "covers/headset-mic.jpg": require("../../assets/covers/headset-mic.jpg"),
  "covers/headset-over-ear.jpg": require("../../assets/covers/headset-over-ear.jpg"),
  "covers/headset-rgb.jpg": require("../../assets/covers/headset-rgb.jpg"),
  "covers/hff.jpg": require("../../assets/covers/hff.jpg"),
  "covers/hfw.jpg": require("../../assets/covers/hfw.jpg"),
  "covers/hfw2.jpg": require("../../assets/covers/hfw2.jpg"),
  "covers/hk.jpg": require("../../assets/covers/hk.jpg"),
  "covers/kit-accesorios-switch-1.png": require("../../assets/covers/kit-accesorios-switch-1.png"),
  "covers/kit-accesorios-switch-2.jpg": require("../../assets/covers/kit-accesorios-switch-2.jpg"),
  "covers/l4d2.jpg": require("../../assets/covers/l4d2.jpg"),
  "covers/little.jpg": require("../../assets/covers/little.jpg"),
  "covers/mgs.jpg": require("../../assets/covers/mgs.jpg"),
  "covers/miles.jpg": require("../../assets/covers/miles.jpg"),
  "covers/mk11.jpg": require("../../assets/covers/mk11.jpg"),
  "covers/nier.jpg": require("../../assets/covers/nier.jpg"),
  "covers/odyssey.jpg": require("../../assets/covers/odyssey.jpg"),
  "covers/p5r.jpg": require("../../assets/covers/p5r.jpg"),
  "covers/rdr2.jpg": require("../../assets/covers/rdr2.jpg"),
  "covers/re2.jpg": require("../../assets/covers/re2.jpg"),
  "covers/re4.jpg": require("../../assets/covers/re4.jpg"),
  "covers/requiem.jpg": require("../../assets/covers/requiem.jpg"),
  "covers/sekiro.jpg": require("../../assets/covers/sekiro.jpg"),
  "covers/setup-pc-gamer.jpg": require("../../assets/covers/setup-pc-gamer.jpg"),
  "covers/sf6.jpg": require("../../assets/covers/sf6.jpg"),
  "covers/sims4.jpg": require("../../assets/covers/sims4.jpg"),
  "covers/sm2.jpg": require("../../assets/covers/sm2.jpg"),
  "covers/smash.jpg": require("../../assets/covers/smash.jpg"),
  "covers/spiderman.jpg": require("../../assets/covers/spiderman.jpg"),
  "covers/tlou1.jpg": require("../../assets/covers/tlou1.jpg"),
  "covers/tlou2.jpg": require("../../assets/covers/tlou2.jpg"),
  "covers/witcher.jpg": require("../../assets/covers/witcher.jpg"),
  "heroes/gowr.jpg": require("../../assets/heroes/gowr.jpg"),
  "heroes/hfw.jpg": require("../../assets/heroes/hfw.jpg"),
  "heroes/logo-gamevault.png": require("../../assets/heroes/logo-gamevault.png"),
  "heroes/miles.jpg": require("../../assets/heroes/miles.jpg"),
  "heroes/portada.jpg": require("../../assets/heroes/portada.jpg"),
  "heroes/rdr2.jpg": require("../../assets/heroes/rdr2.jpg"),
  "heroes/sm2.jpg": require("../../assets/heroes/sm2.jpg"),
  "heroes/spiderman.jpg": require("../../assets/heroes/spiderman.jpg"),
  "heroes/tlou2.jpg": require("../../assets/heroes/tlou2.jpg"),
};


export const CATALOG = [
  {
    "id": "sm2",
    "title": "Marvel's Spider-Man 2",
    "platforms": [
      "PS5"
    ],
    "price": 1199,
    "rating": 4.8,
    "reviews": 1860,
    "image": "covers/sm2.jpg",
    "hero": "heroes/sm2.jpg",
    "blurb": "Peter y Miles comparten Nueva York en una secuela más grande, más rápida y con un nuevo simbionte.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "tlou2",
    "title": "The Last of Us Part II",
    "platforms": [
      "PS5"
    ],
    "price": 699,
    "compareAt": 999,
    "rating": 4.9,
    "reviews": 232,
    "image": "covers/tlou2.jpg",
    "hero": "heroes/tlou2.jpg",
    "blurb": "La historia de Ellie en un mundo postapocalíptico: acción, supervivencia y decisiones que lo cambian todo.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "rdr2",
    "title": "Red Dead Redemption II",
    "platforms": [
      "PS4",
      "PS5"
    ],
    "price": 599,
    "compareAt": 1099,
    "rating": 4.9,
    "reviews": 4210,
    "image": "covers/rdr2.jpg",
    "hero": "heroes/rdr2.jpg",
    "blurb": "El oeste de Arthur Morgan, con un mundo abierto enorme y una historia de lealtad y decadencia.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "gowr",
    "title": "God of War Ragnarök",
    "platforms": [
      "PS5"
    ],
    "price": 749,
    "compareAt": 1299,
    "rating": 4.9,
    "reviews": 3104,
    "image": "covers/gowr.jpg",
    "hero": "heroes/gowr.jpg",
    "blurb": "Kratos y Atreus enfrentan el fin de los nueve reinos. Combate brutal y una saga que cierra el círculo.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "hfw",
    "title": "Horizon Forbidden West",
    "platforms": [
      "PS5"
    ],
    "price": 699,
    "compareAt": 1199,
    "rating": 4.7,
    "reviews": 980,
    "image": "covers/hfw.jpg",
    "hero": "heroes/hfw.jpg",
    "blurb": "Aloy cruza una frontera peligrosa para detener una plaga que amenaza lo que queda de la Tierra.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "bond",
    "title": "007 First Light",
    "platforms": [
      "PS5"
    ],
    "price": 1499,
    "rating": 4.6,
    "reviews": 640,
    "image": "covers/bond.jpg",
    "blurb": "El origen de un agente: espionaje, persecuciones y el primer encargo que convierte a Bond en 007.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "requiem",
    "title": "Resident Evil Requiem",
    "platforms": [
      "PS5"
    ],
    "price": 1399,
    "rating": 4.5,
    "reviews": 410,
    "image": "covers/requiem.jpg",
    "blurb": "El horror vuelve a Raccoon con Leon en el centro de un brote que no debió despertar.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "re4",
    "title": "Resident Evil 4",
    "platforms": [
      "PS5"
    ],
    "price": 649,
    "compareAt": 899,
    "rating": 4.8,
    "reviews": 2500,
    "image": "covers/re4.jpg",
    "blurb": "Leon Kennedy rescata a la hija del presidente en un pueblo que ya no pertenece a los vivos.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "re2",
    "title": "Resident Evil 2",
    "platforms": [
      "PS5"
    ],
    "price": 549,
    "compareAt": 799,
    "rating": 4.8,
    "reviews": 1900,
    "image": "covers/re2.jpg",
    "blurb": "Raccoon City cae en una noche. Claire y Leon buscan la salida entre el departamento y el laboratorio.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "odyssey",
    "title": "Super Mario Odyssey",
    "platforms": [
      "Switch"
    ],
    "price": 999,
    "compareAt": 1110,
    "rating": 4.9,
    "reviews": 5400,
    "image": "covers/odyssey.jpg",
    "blurb": "Mario y Cappy recorren reinos imposibles para detener la boda de Bowser. Plataformas en estado puro.",
    "format": "Físico",
    "featured": true,
    "kind": "juego",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "smash",
    "title": "Super Smash Bros. Ultimate",
    "platforms": [
      "Switch"
    ],
    "price": 999,
    "compareAt": 1149,
    "rating": 4.9,
    "reviews": 6200,
    "image": "covers/smash.jpg",
    "blurb": "Todos los luchadores, todos los escenarios. El crossover de pelea para jugar en el sofá o en serio.",
    "format": "Físico",
    "kind": "juego",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "hk",
    "title": "Hollow Knight",
    "platforms": [
      "PC",
      "Switch"
    ],
    "price": 99,
    "compareAt": 499,
    "rating": 4.9,
    "reviews": 8700,
    "image": "covers/hk.jpg",
    "blurb": "Un reino de insectos bajo tierra. Exploración, combate preciso y un mapa que no suelta.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "nier",
    "title": "NieR:Automata",
    "platforms": [
      "PS4",
      "PC"
    ],
    "price": 349,
    "compareAt": 699,
    "rating": 4.8,
    "reviews": 4100,
    "image": "covers/nier.jpg",
    "blurb": "Androides en una guerra que ya no tiene humanos. Acción y una historia que pide la segunda vuelta.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "mk11",
    "title": "Mortal Kombat 11",
    "platforms": [
      "PS5",
      "Xbox",
      "PC"
    ],
    "price": 199,
    "compareAt": 1329,
    "rating": 4.6,
    "reviews": 3300,
    "image": "covers/mk11.jpg",
    "blurb": "Fatalities, el reloj de arena roto y un roster que mezcla presente y pasado del torneo.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "p5r",
    "title": "Persona 5 Royal",
    "platforms": [
      "PS4",
      "PS5"
    ],
    "price": 849,
    "compareAt": 999,
    "rating": 4.9,
    "reviews": 2800,
    "image": "covers/p5r.jpg",
    "blurb": "Ladrones fantasma de día y estudiantes de noche. Estilo, palacios y un semestre que se alarga en Royal.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "dsr",
    "title": "Dark Souls Remastered",
    "platforms": [
      "PS4",
      "Switch",
      "PC"
    ],
    "price": 399,
    "compareAt": 569,
    "rating": 4.7,
    "reviews": 2100,
    "image": "covers/dsr.jpg",
    "blurb": "Lordran, hogueras y un combate que castiga la prisa. La puerta de entrada al género, remasterizada.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "halo",
    "title": "Halo Infinite",
    "platforms": [
      "Xbox",
      "PC"
    ],
    "price": 499,
    "compareAt": 589,
    "rating": 4.3,
    "reviews": 1500,
    "image": "covers/halo.jpg",
    "blurb": "El Jefe regresa a Zeta Halo. Campaña abierta y multijugador de arena con el gancho de grappling.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "batman",
    "title": "Batman: Arkham City",
    "platforms": [
      "PC",
      "Xbox"
    ],
    "price": 249,
    "compareAt": 629,
    "rating": 4.8,
    "reviews": 3600,
    "image": "covers/batman.jpg",
    "blurb": "Una prisión del tamaño de un distrito. Planeo, sigilo y los villanos de Gotham en el mismo mapa.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "gtasa",
    "title": "Grand Theft Auto: San Andreas",
    "platforms": [
      "PC",
      "PS4"
    ],
    "price": 199,
    "compareAt": 499,
    "rating": 4.7,
    "reviews": 2900,
    "image": "covers/gtasa.jpg",
    "blurb": "CJ vuelve a Los Santos. Bandas, radio y un estado entero para recorrer en bicicleta o en lowrider.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "gta5",
    "title": "Grand Theft Auto V",
    "platforms": [
      "PS5",
      "Xbox",
      "PC"
    ],
    "price": 399,
    "rating": 4.6,
    "reviews": 9800,
    "image": "covers/gta5.jpg",
    "blurb": "Tres protagonistas y un condado de robos. Historia cinematográfica y el sandbox que nunca se apaga.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "l4d2",
    "title": "Left 4 Dead 2",
    "platforms": [
      "PC"
    ],
    "price": 149,
    "compareAt": 499,
    "rating": 4.8,
    "reviews": 7600,
    "image": "covers/l4d2.jpg",
    "blurb": "Cuatro supervivientes, hordas y un director de IA que no deja dos partidas iguales.",
    "format": "Digital",
    "kind": "juego",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "sf6",
    "title": "Street Fighter 6",
    "platforms": [
      "PS5",
      "Xbox",
      "PC"
    ],
    "price": 799,
    "compareAt": 1332,
    "rating": 4.7,
    "reviews": 2200,
    "image": "covers/sf6.jpg",
    "blurb": "Drive system, un modo mundo para aprender y el elenco clásico junto a una generación nueva.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "dmc5",
    "title": "Devil May Cry 5",
    "platforms": [
      "PS5",
      "Xbox",
      "PC"
    ],
    "price": 399,
    "compareAt": 665,
    "rating": 4.8,
    "reviews": 3400,
    "image": "covers/dmc5.jpg",
    "blurb": "Dante, Nero y V contra un árbol demoníaco. Combos largos y un estilo que no pide disculpas.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "dbx2",
    "title": "Dragon Ball Xenoverse 2",
    "platforms": [
      "PS4",
      "Switch",
      "Xbox",
      "PC"
    ],
    "price": 349,
    "compareAt": 499,
    "rating": 4.4,
    "reviews": 1800,
    "image": "covers/dbx2.jpg",
    "blurb": "Crea tu guerrero y corrige la historia. Arenas, razas y un elenco que sigue creciendo.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "gang",
    "title": "Gang Beasts",
    "platforms": [
      "PS4",
      "PC"
    ],
    "price": 89,
    "compareAt": 599,
    "rating": 4.2,
    "reviews": 900,
    "image": "covers/gang.jpg",
    "blurb": "Gelatina, puños y gravity. El party de peleas absurdas para terminar una noche con amigos.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "hff",
    "title": "Human Fall Flat",
    "platforms": [
      "Switch",
      "PC"
    ],
    "price": 199,
    "compareAt": 306,
    "rating": 4.5,
    "reviews": 2600,
    "image": "covers/hff.jpg",
    "blurb": "Un muñeco sin huesos resuelve puzzles. Mejor en cooperativo, peor para la dignidad.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "little",
    "title": "Little Nightmares",
    "platforms": [
      "PS4",
      "Switch",
      "PC"
    ],
    "price": 199,
    "compareAt": 642,
    "rating": 4.7,
    "reviews": 1500,
    "image": "covers/little.jpg",
    "blurb": "Six y un impermeable amarillo en un barco que no debería existir. Terror pequeño y muy físico.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "bully",
    "title": "Bully",
    "platforms": [
      "PC"
    ],
    "price": 99,
    "compareAt": 990,
    "rating": 4.6,
    "reviews": 1200,
    "image": "covers/bully.jpg",
    "blurb": "La academia Bullworth, clases, bandas del patio y un año escolar que se sale de control.",
    "format": "Digital",
    "kind": "juego",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "sims4",
    "title": "The Sims 4",
    "platforms": [
      "PC"
    ],
    "price": 299,
    "compareAt": 332,
    "rating": 4.2,
    "reviews": 5400,
    "image": "covers/sims4.jpg",
    "blurb": "Construye la casa, la carrera y el drama. Un sandbox de vida sin objetivo obligatorio.",
    "format": "Digital",
    "kind": "juego",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "forza5",
    "title": "Forza Horizon 5",
    "platforms": [
      "Xbox",
      "PC"
    ],
    "price": 799,
    "compareAt": 1142,
    "rating": 4.8,
    "reviews": 4700,
    "image": "covers/forza5.jpg",
    "blurb": "México a toda velocidad: volcanes, jungla y un festival que premia conducir bonito.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "acmirage",
    "title": "Assassin's Creed Mirage",
    "platforms": [
      "PS5",
      "Xbox",
      "PC"
    ],
    "price": 499,
    "compareAt": 1249,
    "rating": 4.4,
    "reviews": 860,
    "image": "covers/acmirage.jpg",
    "blurb": "Basim en el Bagdad del siglo IX. Sigilo, tejados y un Assassin's Creed más corto y directo.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "acshadows",
    "title": "Assassin's Creed Shadows",
    "platforms": [
      "PS5",
      "Xbox"
    ],
    "price": 1299,
    "rating": 4.6,
    "reviews": 720,
    "image": "covers/acshadows.jpg",
    "blurb": "Japón feudal con dos formas de jugar: la sombra de Naoe y la fuerza de Yasuke.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "gears5",
    "title": "Gears 5",
    "platforms": [
      "Xbox",
      "PC"
    ],
    "price": 499,
    "compareAt": 768,
    "rating": 4.5,
    "reviews": 1600,
    "image": "covers/gears5.jpg",
    "blurb": "Kait busca el origen de los Locust. Cobertura, escopeta y una campaña que abre el mapa.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "mgs",
    "title": "Metal Gear Solid V",
    "platforms": [
      "PS4",
      "Xbox",
      "PC"
    ],
    "price": 299,
    "compareAt": 499,
    "rating": 4.8,
    "reviews": 3900,
    "image": "covers/mgs.jpg",
    "blurb": "Afganistán y África abiertos. Infiltración, caballo y el silencio de Venom Snake.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "cyber",
    "title": "Cyberpunk 2077",
    "platforms": [
      "PS5",
      "Xbox",
      "PC"
    ],
    "price": 599,
    "rating": 4.4,
    "reviews": 5100,
    "image": "covers/cyber.jpg",
    "blurb": "Night City de noche, un chip en la cabeza y demasiadas corporaciones con tu nombre.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "elden",
    "title": "Elden Ring",
    "platforms": [
      "PS5",
      "Xbox",
      "PC"
    ],
    "price": 899,
    "rating": 4.9,
    "reviews": 8900,
    "image": "covers/elden.jpg",
    "blurb": "Las Tierras Intermedias a caballo. Jefes enormes y secretos que el mapa no marca.",
    "featured": true,
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "witcher",
    "title": "The Witcher 3: Wild Hunt",
    "platforms": [
      "PS5",
      "Switch",
      "PC"
    ],
    "price": 349,
    "rating": 4.9,
    "reviews": 9200,
    "image": "covers/witcher.jpg",
    "blurb": "Geralt, contratos y dos expansiones que muchos consideran lo mejor de la saga.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "sekiro",
    "title": "Sekiro: Shadows Die Twice",
    "platforms": [
      "PS4",
      "Xbox",
      "PC"
    ],
    "price": 599,
    "rating": 4.8,
    "reviews": 2700,
    "image": "covers/sekiro.jpg",
    "blurb": "Japón sengoku, una prótesis y un combate de postura donde desviar vale más que esquivar.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "miles",
    "title": "Marvel's Spider-Man: Miles Morales",
    "platforms": [
      "PS5"
    ],
    "price": 899,
    "rating": 4.8,
    "reviews": 1400,
    "image": "covers/miles.jpg",
    "hero": "heroes/miles.jpg",
    "blurb": "El Harlem de Miles en invierno. Venom punch, un traje nuevo y una ciudad más íntima.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "spiderman",
    "title": "Marvel's Spider-Man",
    "platforms": [
      "PS5"
    ],
    "price": 699,
    "compareAt": 999,
    "rating": 4.8,
    "reviews": 3600,
    "image": "covers/spiderman.jpg",
    "hero": "heroes/spiderman.jpg",
    "blurb": "Peter ya es Spider-Man. Oscorp, el Kingpin y el balanceo que definió a la generación.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "gow",
    "title": "God of War",
    "platforms": [
      "PS5"
    ],
    "price": 649,
    "rating": 4.9,
    "reviews": 4500,
    "image": "covers/gow.jpg",
    "blurb": "El viaje de Kratos y Atreus para esparcir las cenizas en la cima más alta de los reinos.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "tlou1",
    "title": "The Last of Us Part I",
    "platforms": [
      "PS5"
    ],
    "price": 799,
    "rating": 4.8,
    "reviews": 2100,
    "image": "covers/tlou1.jpg",
    "blurb": "Joel y Ellie cruzan un país en ruinas. La remaster de PS5 con el viaje original intacto.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "hzd",
    "title": "Horizon Zero Dawn",
    "platforms": [
      "PS5"
    ],
    "price": 499,
    "compareAt": 899,
    "rating": 4.8,
    "reviews": 3800,
    "image": "covers/hfw2.jpg",
    "blurb": "El origen de Aloy y de las máquinas. Tribus, ruinas y la pregunta de quién construyó el mundo.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "cod3",
    "title": "Call of Duty: Black Ops III",
    "platforms": [
      "PS4",
      "Xbox",
      "PC"
    ],
    "price": 399,
    "compareAt": 665,
    "rating": 4.3,
    "reviews": 2400,
    "image": "covers/cod3.jpg",
    "blurb": "Campaña de supersoldados, zombies y un multijugador que todavía llena salas.",
    "kind": "juego",
    "format": "Ambos",
    "mat": "dark",
    "contain": false,
    "usedOk": true
  },
  {
    "id": "ps5",
    "title": "PlayStation 5",
    "kind": "consola",
    "platforms": [
      "PS5"
    ],
    "price": 9499,
    "rating": 4.8,
    "reviews": 860,
    "image": "covers/console-ps5.jpg",
    "blurb": "SSD ultrarrápido, DualSense y el catálogo de PlayStation en 4K. Incluye un control.",
    "mat": "dark",
    "usedOk": false,
    "format": "Físico",
    "contain": true
  },
  {
    "id": "ps4",
    "title": "PlayStation 4",
    "kind": "consola",
    "platforms": [
      "PS4"
    ],
    "price": 5999,
    "rating": 4.6,
    "reviews": 1400,
    "image": "covers/console-ps4.jpg",
    "blurb": "La generación del catálogo enorme. Ideal si buscas juegos físicos a mejor precio.",
    "mat": "light",
    "usedOk": false,
    "format": "Físico",
    "contain": true
  },
  {
    "id": "ps4-pro-gow-limited",
    "title": "Sony PlayStation 4 Pro 1TB Edición Limitada God of War",
    "kind": "consola",
    "platforms": [
      "PS4"
    ],
    "price": 8999,
    "image": "covers/console-ps4-pro-god-of-war.jpg",
    "blurb": "Consola PS4 Pro de 1TB en acabado Leviathan Grey inspirado en el Hacha del Leviatán, con mando DUALSHOCK 4 a juego y God of War Day One Edition. Edición limitada.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true,
    "customEdition": true,
    "limitedEdition": true,
    "sku": "711719510239",
    "modelCode": "CUH-7115B",
    "bundleContents": [
      "Consola PlayStation 4 Pro 1TB Edición Limitada God of War",
      "Mando inalámbrico DUALSHOCK 4 edición Leviathan Grey",
      "God of War Day One Edition en Blu-ray"
    ]
  },
  {
    "id": "xsx",
    "title": "Xbox Series X",
    "kind": "consola",
    "platforms": [
      "Xbox"
    ],
    "price": 8999,
    "rating": 4.7,
    "reviews": 740,
    "image": "covers/console-xbox-series-x.jpg",
    "blurb": "La caja negra de 12 teraflops, Quick Resume y Game Pass listo para conectar.",
    "mat": "light",
    "usedOk": false,
    "format": "Físico",
    "contain": true
  },
  {
    "id": "switch",
    "title": "Nintendo Switch",
    "kind": "consola",
    "platforms": [
      "Switch"
    ],
    "price": 6499,
    "rating": 4.8,
    "reviews": 2100,
    "image": "covers/console-switch.jpg",
    "blurb": "Híbrida de sobremesa y portátil, con Joy-Con azul y rojo. Mario, Zelda y el sofá.",
    "mat": "dark",
    "usedOk": false,
    "format": "Físico",
    "contain": true
  },
  {
    "id": "dualsense",
    "title": "DualSense",
    "kind": "accesorio",
    "platforms": [
      "PS5"
    ],
    "price": 1499,
    "rating": 4.7,
    "reviews": 980,
    "image": "covers/control-dualsense.jpg",
    "blurb": "Gatillos adaptativos, hápticos y batería para sesiones largas. Blanco clásico.",
    "mat": "light",
    "usedOk": false,
    "format": "Físico",
    "contain": true
  },
  {
    "id": "xpad",
    "title": "Control inalámbrico Xbox",
    "kind": "accesorio",
    "platforms": [
      "Xbox",
      "PC"
    ],
    "price": 1299,
    "rating": 4.6,
    "reviews": 640,
    "image": "covers/control-xbox.jpg",
    "blurb": "El mando de Xbox en PC y consola. Agarres texturizados y compartir con un botón.",
    "mat": "light",
    "usedOk": false,
    "format": "Físico",
    "contain": true
  },
  {
    "id": "xss-bmo",
    "title": "Xbox Series S Edición BMO",
    "kind": "consola",
    "platforms": [
      "Xbox"
    ],
    "price": 9999,
    "image": "covers/console-xbox-bmo.jpg",
    "blurb": "Edición personalizada inspirada en BMO, con consola y control a juego. Diseño estampado.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true,
    "customEdition": true
  },
  {
    "id": "ps5-spiderman",
    "title": "PlayStation 5 Edición Spider-Man",
    "kind": "consola",
    "platforms": [
      "PS5"
    ],
    "price": 10499,
    "image": "covers/console-ps5-spiderman.jpg",
    "blurb": "Consola PlayStation 5 con diseño gráfico de Spider-Man. Edición estampada.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true,
    "customEdition": true
  },
  {
    "id": "switch-splatoon",
    "title": "Nintendo Switch Edición Splatoon",
    "kind": "consola",
    "platforms": [
      "Switch"
    ],
    "price": 6999,
    "image": "covers/console-switch-splatoon.jpg",
    "blurb": "Nintendo Switch con Joy-Con de colores y diseño inspirado en Splatoon. Edición estampada.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true,
    "customEdition": true
  },
  {
    "id": "dualsense-spiderman",
    "title": "Control DualSense Edición Spider-Man",
    "kind": "accesorio",
    "platforms": [
      "PS5"
    ],
    "price": 1799,
    "image": "covers/control-dualsense-spiderman.jpg",
    "blurb": "Control inalámbrico DualSense con acabado gráfico de Spider-Man. Edición estampada.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true,
    "customEdition": true
  },
  {
    "id": "dualshock4-pack",
    "title": "Paquete de 2 controles PS4",
    "kind": "accesorio",
    "platforms": [
      "PS4"
    ],
    "price": 1799,
    "image": "covers/control-ps4-pack.jpg",
    "blurb": "Dos controles inalámbricos para PlayStation 4, uno rojo y uno azul.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "headset-rgb",
    "title": "Audífonos Gamer RGB",
    "kind": "accesorio",
    "platforms": [],
    "price": 1299,
    "image": "covers/headset-rgb.jpg",
    "blurb": "Audífonos gamer con micrófono integrado y detalles de iluminación RGB.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "headset-mic",
    "title": "Audífonos Gamer con Micrófono",
    "kind": "accesorio",
    "platforms": [],
    "price": 999,
    "image": "covers/headset-mic.jpg",
    "blurb": "Diadema gamer acolchada con micrófono integrado para comunicación durante las partidas.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "headset-over-ear",
    "title": "Audífonos Gamer Over-Ear",
    "kind": "accesorio",
    "platforms": [],
    "price": 1499,
    "image": "covers/headset-over-ear.jpg",
    "blurb": "Audífonos circumaurales con almohadillas amplias y micrófono abatible.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "chair-gray",
    "title": "Silla Gamer Gris",
    "kind": "accesorio",
    "platforms": [],
    "price": 3499,
    "image": "covers/chair-gray.jpg",
    "blurb": "Silla gamer acolchada en tonos gris y negro, con reposabrazos y base giratoria.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "chair-red",
    "title": "Silla Gamer Roja y Negra",
    "kind": "accesorio",
    "platforms": [],
    "price": 3999,
    "image": "covers/chair-red-black.jpg",
    "blurb": "Silla gamer acolchada con diseño deportivo rojo y negro, reposabrazos y base giratoria.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "pc-gamer-setup",
    "title": "Set PC Gamer con Monitor y Periféricos",
    "kind": "equipo",
    "platforms": [
      "PC"
    ],
    "price": 21999,
    "image": "covers/setup-pc-gamer.jpg",
    "blurb": "Conjunto gamer con torre, monitor, teclado, mouse y audífonos. La imagen representa el paquete; las especificaciones se confirman al cotizar.",
    "format": "Físico",
    "mat": "dark",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "kit-accesorios-switch-2",
    "title": "Kit de Accesorios para Nintendo Switch 2",
    "kind": "accesorio",
    "platforms": [
      "Switch 2"
    ],
    "price": 899,
    "image": "covers/kit-accesorios-switch-2.jpg",
    "blurb": "Kit de accesorios para Nintendo Switch 2 con estuche de transporte, protectores de pantalla, funda, soporte, grips y accesorios de protección.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  },
  {
    "id": "kit-accesorios-switch-1",
    "title": "Kit de Accesorios 12 en 1 para Nintendo Switch",
    "kind": "accesorio",
    "platforms": [
      "Switch"
    ],
    "price": 799,
    "rating": 4.8,
    "reviews": 0,
    "image": "covers/kit-accesorios-switch-1.png",
    "blurb": "Paquete de accesorios para Nintendo Switch con estuche de transporte, funda protectora, protectores de pantalla, grips para Joy-Con, soporte, organizador de tarjetas y accesorios adicionales.",
    "format": "Físico",
    "mat": "light",
    "usedOk": false,
    "contain": true
  }
];

export const ABOUT = [
  "¿A qué nos referimos con una experiencia de compra sencilla? Muchas veces, al buscar un videojuego, nos encontramos con páginas poco intuitivas, precios confusos, información incompleta o procesos de compra demasiado complicados.",
  "Entre tantos obstáculos, lo que debería ser una experiencia emocionante para cualquier gamer puede terminar convirtiéndose en una verdadera frustración. Por eso GameVault nace para comprar y vender juegos físicos y digitales de forma fácil, rápida y segura.",
  "Queremos que encuentres tus títulos favoritos, descubras nuevas aventuras y consigas las mejores opciones sin complicaciones, con toda la información al alcance de un clic."
];

export const OFFERS = [
  {
    "name": "Zelda: Ocarina of Time",
    "off": 40
  },
  {
    "name": "Left 4 Dead 2",
    "off": 70,
    "productId": "l4d2"
  },
  {
    "name": "Forza Horizon 5",
    "off": 30,
    "productId": "forza5"
  },
  {
    "name": "Red Dead Redemption II",
    "off": 45,
    "productId": "rdr2"
  },
  {
    "name": "Blur",
    "off": 80
  },
  {
    "name": "Mortal Kombat 11",
    "off": 85,
    "productId": "mk11"
  },
  {
    "name": "Street Fighter 6",
    "off": 40,
    "productId": "sf6"
  },
  {
    "name": "Devil May Cry 5",
    "off": 40,
    "productId": "dmc5"
  },
  {
    "name": "Assassin's Creed Mirage",
    "off": 60,
    "productId": "acmirage"
  },
  {
    "name": "Super Mario Odyssey",
    "off": 10,
    "productId": "odyssey"
  },
  {
    "name": "Super Smash Bros. Ultimate",
    "off": 13,
    "productId": "smash"
  },
  {
    "name": "NieR:Automata",
    "off": 50,
    "productId": "nier"
  },
  {
    "name": "The Simpsons Hit & Run",
    "off": 70
  },
  {
    "name": "Hollow Knight",
    "off": 80,
    "productId": "hk"
  },
  {
    "name": "GTA San Andreas",
    "off": 60,
    "productId": "gtasa"
  },
  {
    "name": "Bully",
    "off": 90,
    "productId": "bully"
  },
  {
    "name": "Toy Story 3",
    "off": 25
  },
  {
    "name": "The LEGO Ninjago Movie",
    "off": 30
  },
  {
    "name": "Call of Duty: Black Ops III",
    "off": 40,
    "productId": "cod3"
  },
  {
    "name": "Call of Duty: Black Ops II",
    "off": 25
  },
  {
    "name": "The Sims 4",
    "off": 10,
    "productId": "sims4"
  },
  {
    "name": "Little Nightmares",
    "off": 69,
    "productId": "little"
  },
  {
    "name": "Dragon Ball Xenoverse 2",
    "off": 30,
    "productId": "dbx2"
  },
  {
    "name": "Kirby and the Forgotten Land",
    "off": 20
  },
  {
    "name": "Persona 5 Royal",
    "off": 15,
    "productId": "p5r"
  },
  {
    "name": "Dark Souls Remastered",
    "off": 30,
    "productId": "dsr"
  },
  {
    "name": "Ghost of Yōtei",
    "off": 20
  },
  {
    "name": "Metal Gear Solid V",
    "off": 40,
    "productId": "mgs"
  },
  {
    "name": "Gang Beasts",
    "off": 85,
    "productId": "gang"
  },
  {
    "name": "Human Fall Flat",
    "off": 35,
    "productId": "hff"
  },
  {
    "name": "Marvel's Spider-Man",
    "off": 30,
    "productId": "spiderman"
  },
  {
    "name": "Shadow of the Colossus",
    "off": 45
  },
  {
    "name": "Halo Infinite",
    "off": 15,
    "productId": "halo"
  },
  {
    "name": "Batman: Arkham City",
    "off": 60,
    "productId": "batman"
  },
  {
    "name": "Gears 5",
    "off": 35,
    "productId": "gears5"
  }
];

export const TAGLINE = "Porque conseguir tu próximo videojuego debería ser tan emocionante como jugarlo.";

export const DESIGNERS = [
  "Juan Ángel Ríos Alaniz",
  "Diego Díaz Rentería",
  "Ricardo García Roldán"
];

export function getImage(path) {
  if (!path) return null;
  return images[path] || null;
}

export const KINDS = [
  { id: "all", label: "Todos" },
  { id: "juego", label: "Juegos" },
  { id: "consola", label: "Consolas" },
  { id: "accesorio", label: "Accesorios" },
  { id: "equipo", label: "Equipo" },
];

export const PLATFORMS = [
  { id: "all", label: "Todas" },
  { id: "PS5", label: "PS5" },
  { id: "PS4", label: "PS4" },
  { id: "Xbox", label: "Xbox" },
  { id: "Switch", label: "Switch" },
  { id: "Switch 2", label: "Switch 2" },
  { id: "PC", label: "PC" },
];
