import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  Pressable,
  Dimensions,
} from 'react-native';
import { getImage } from '../data/catalog';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 48) / 2;

export default function ProductCard({ product, onPress }) {
  const img = getImage(product.image);
  const hasDiscount =
    product.compareAt && product.compareAt > product.price;

  return (
    <Pressable
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
      onPress={() => onPress(product)}
    >
      <View style={styles.imageWrap}>
        {img ? (
          <Image source={img} style={styles.image} resizeMode="cover" />
        ) : (
          <View style={[styles.image, styles.placeholder]}>
            <Text style={styles.placeholderText}>?</Text>
          </View>
        )}
        {hasDiscount && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>
              -
              {Math.round(
                ((product.compareAt - product.price) / product.compareAt) * 100
              )}
              %
            </Text>
          </View>
        )}
      </View>
      <View style={styles.body}>
        <Text style={styles.kind}>{product.kind?.toUpperCase()}</Text>
        <Text style={styles.title} numberOfLines={2}>
          {product.title}
        </Text>
        <Text style={styles.platforms} numberOfLines={1}>
          {(product.platforms || []).join(' · ')}
        </Text>
        <View style={styles.priceRow}>
          <Text style={styles.price}>${product.price}</Text>
          {hasDiscount && (
            <Text style={styles.compare}>${product.compareAt}</Text>
          )}
        </View>
        {product.rating != null && (
          <Text style={styles.rating}>
            ★ {product.rating} · {product.reviews || 0} reseñas
          </Text>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: CARD_WIDTH,
    backgroundColor: '#151922',
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#1f2533',
  },
  pressed: {
    opacity: 0.85,
  },
  imageWrap: {
    width: '100%',
    height: CARD_WIDTH * 1.25,
    backgroundColor: '#0d1017',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  placeholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderText: {
    color: '#555',
    fontSize: 28,
  },
  badge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#e11d48',
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 6,
  },
  badgeText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
  },
  body: {
    padding: 10,
  },
  kind: {
    color: '#7c8aa5',
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.6,
    marginBottom: 2,
  },
  title: {
    color: '#f1f5f9',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 17,
    marginBottom: 3,
  },
  platforms: {
    color: '#94a3b8',
    fontSize: 11,
    marginBottom: 6,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  price: {
    color: '#38bdf8',
    fontSize: 15,
    fontWeight: '700',
  },
  compare: {
    color: '#64748b',
    fontSize: 12,
    textDecorationLine: 'line-through',
  },
  rating: {
    color: '#fbbf24',
    fontSize: 11,
    marginTop: 4,
  },
});
