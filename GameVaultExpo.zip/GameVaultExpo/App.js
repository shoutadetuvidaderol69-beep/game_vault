import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { CartProvider, useCart } from './src/context/CartContext';
import HomeScreen from './src/screens/HomeScreen';
import BrowseScreen from './src/screens/BrowseScreen';
import CartScreen from './src/screens/CartScreen';
import AboutScreen from './src/screens/AboutScreen';
import ProductScreen from './src/screens/ProductScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const theme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: '#0b0d12',
    card: '#0b0d12',
    border: '#1f2533',
    primary: '#0ea5e9',
    text: '#f1f5f9',
  },
};

function TabIcon({ label, focused }) {
  const icons = {
    Inicio: '🏠',
    Explorar: '🔍',
    Carrito: '🛒',
    Info: 'ℹ️',
  };
  return (
    <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.55 }}>
      {icons[label] || '•'}
    </Text>
  );
}

function MainTabs() {
  const { count } = useCart();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#0f1219',
          borderTopColor: '#1f2533',
          height: 60,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarActiveTintColor: '#38bdf8',
        tabBarInactiveTintColor: '#64748b',
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
        tabBarIcon: ({ focused }) => (
          <TabIcon label={route.name} focused={focused} />
        ),
      })}
    >
      <Tab.Screen name="Inicio" component={HomeScreen} />
      <Tab.Screen name="Explorar" component={BrowseScreen} />
      <Tab.Screen
        name="Carrito"
        component={CartScreen}
        options={{
          tabBarBadge: count > 0 ? count : undefined,
          tabBarBadgeStyle: {
            backgroundColor: '#e11d48',
            fontSize: 10,
            minWidth: 18,
            height: 18,
          },
        }}
      />
      <Tab.Screen name="Info" component={AboutScreen} />
    </Tab.Navigator>
  );
}

function RootNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Main" component={MainTabs} />
      <Stack.Screen
        name="Product"
        component={ProductScreen}
        options={{ animation: 'slide_from_right' }}
      />
      {/* Allow navigating to Cart / Browse from other screens by name */}
      <Stack.Screen name="Cart" component={CartScreen} />
      <Stack.Screen name="Browse" component={BrowseScreen} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <CartProvider>
        <NavigationContainer theme={theme}>
          <StatusBar style="light" />
          <RootNavigator />
        </NavigationContainer>
      </CartProvider>
    </SafeAreaProvider>
  );
}
