# GameVault – Expo / Expo Go

Versión móvil del catálogo GameVault para **Expo Go**.

## Requisitos

- Node.js 18 o superior
- App **Expo Go** instalada en tu teléfono (Android o iOS)
  - Android: [Google Play](https://play.google.com/store/apps/details?id=host.exp.exponent)
  - iOS: [App Store](https://apps.apple.com/app/expo-go/id982107779)

## Cómo correrlo (paso a paso)

### 1. Extrae / abre la carpeta

Usa la carpeta `GameVaultExpo` (la que contiene `package.json` y `App.js`).

### 2. Instala dependencias

Abre una terminal **dentro de la carpeta GameVaultExpo** y ejecuta:

```bash
npm install
```

### 3. Inicia el servidor de Expo

```bash
npx expo start
```

Se abrirá una ventana en el navegador y en la terminal verás un **código QR**.

### 4. Ábrelo en tu teléfono con Expo Go

1. Asegúrate de que el teléfono y la computadora estén en la **misma red WiFi**.
2. Abre la app **Expo Go**.
3. Escanea el código QR:
   - **Android**: desde dentro de Expo Go → “Scan QR code”.
   - **iOS**: con la cámara del sistema (abre el enlace en Expo Go).

La app se cargará en tu teléfono.

---

## Si el QR no funciona (red diferente / firewall)

En la terminal, después de `npx expo start`, prueba:

```bash
npx expo start --tunnel
```

Esto usa un túnel de Expo y funciona aunque no estén en la misma WiFi (puede tardar un poco más en conectar).

---

## Estructura principal

```
GameVaultExpo/
├── App.js                 # Navegación principal
├── app.json               # Configuración de Expo
├── package.json
├── assets/
│   ├── covers/            # Portadas de productos
│   └── heroes/            # Imágenes grandes y logo
└── src/
    ├── data/catalog.js    # Catálogo + imágenes
    ├── context/CartContext.js
    ├── components/ProductCard.js
    └── screens/
        ├── HomeScreen.js
        ├── BrowseScreen.js
        ├── ProductScreen.js
        ├── CartScreen.js
        └── AboutScreen.js
```

## Funcionalidades

- Catálogo completo (juegos, consolas, accesorios, equipo)
- Búsqueda y filtros por tipo y plataforma
- Productos destacados en inicio
- Detalle de producto
- Carrito con cantidades (se guarda en el teléfono)
- Simulación de métodos de pago (demo, sin cargos reales)
- Tema oscuro adaptado a móvil

## Notas

- Los precios y el checkout son de demostración.
- No se conecta a internet para pagos ni a bases de datos externas.
- Todas las imágenes van incluidas en el proyecto.

¡Listo! Con `npm install` + `npx expo start` y Expo Go deberías ver GameVault en tu teléfono.
